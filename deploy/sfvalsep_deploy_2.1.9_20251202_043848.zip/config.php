<?php
/**
 * Archivo de configuración principal (legacy style variables preserved)
 * - Añadido: modo debug
 * - Por seguridad, cambia estos valores en producción
 */

// Modo debug: true para mostrar errores, false para ocultarlos
$debug = true;
if ($debug) {
	ini_set('display_errors', '1');
	error_reporting(E_ALL);
} else {
	ini_set('display_errors', '0');
	error_reporting(0);
}

// Credenciales de ejemplo (dev). El instalador pedirá y sobrescribirá si usas otro set.
$dbhost = '127.0.0.1';
$dbname = 'susitiocl_gallery';
$dbuser = 'root';
$dbpass = '';

// Nota: la información de la galería ahora se gestiona desde la tabla `settings` vía el panel admin.
// Evita hardcoding aquí; usa `admin.php` para cambiar `gallery_name`, `access_mode`, etc.

?>
